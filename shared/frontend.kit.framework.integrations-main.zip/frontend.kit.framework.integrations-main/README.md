# Frontend-Kit - Framework integrations & BDDS Design Tokens

This repo is meant to showcase the usage of the Frontend-Kit and BDDS design tokens within
a react and angular application.

See the respective packages in `/packages` folder

## Key facts to be aware of

### React Integration

* is built with vite
* needs adjustment of the `vite.config.ts` to enable proper import of **bdds.tokens-npm** and **frontend.kit-npm** artifacts
* `App.scss` includes most of the `css` imports
* `Tile.tsx` shows how to import styles in a component itself

### Angular Integration

* is scaffolded with the `ng cli` tool
* can use the `pkg:` syntax without adjustment
* `public` folder for font assets needs to be referenced in `angular.json`
* `styles.scss` includes most of the `css` imports
* `Tile` component uses `scss` as style file to use `pkg:` imports