import "./App.scss";
import TileSecondary from "./Tile";

function App() {
  return (
    <>
      <div className="e-container">
        <div className="a-text">
          <h1>FROK - React Integration</h1>
          <p>
            With the new frontend-kit version 5.0 you can use 4 different
            brands:
          </p>
          <ul className="a-list a-list--dot">
            <li>Bosch</li>
            <li>Bosch Powertools</li>
            <li>Bosch DiY</li>
            <li>Dremel</li>
          </ul>
          <h2>Component Showcase</h2>
          <div style={{ display: "flex", gap: "1rem" }}>
            <button type="button" className="a-button a-button--brand-primary">
              <i className="a-icon a-button__icon boschicon-bosch-ic-emoji-happy"></i>
              <span className="a-button__label">Button label</span>
            </button>
            <button
              type="button"
              className="a-button a-button--brand-secondary"
            >
              <i className="a-icon a-button__icon boschicon-bosch-ic-emoji-happy"></i>
              <span className="a-button__label">Button label</span>
            </button>
            <button
              type="button"
              className="a-button a-button--destructive-primary"
            >
              <i className="a-icon a-button__icon boschicon-bosch-ic-emoji-happy"></i>
              <span className="a-button__label">Button label</span>
            </button>
          </div>
          <div
            style={{ display: "flex", gap: "1rem", marginBlockStart: "1rem" }}
          >
            <div className="a-checkbox">
              <input type="checkbox" id="checkbox-3" name="selected checkbox" />
              <label htmlFor="checkbox-3">Checkbox Label</label>
            </div>
          </div>
          <div
            style={{ display: "flex", gap: "1rem", marginBlockStart: "1rem" }}
          >
            <div className="a-link -icon">
              <a
                aria-label="Open primary label (default with icon right) Link Label"
                href="https://www.bosch.com"
                target="_self"
              >
                <span>Link </span>
                <span>
                  Label<i className="a-icon ui-ic-nosafe-lr-forward-small"></i>
                </span>
              </a>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: "1rem", marginBlockStart: "1rem" }}>
          <TileSecondary></TileSecondary>
        </div>
        <div
          className="-emphasis-02-nested"
          style={{ padding: "3rem", marginBlockStart: "1rem" }}
        >
          <TileSecondary></TileSecondary>
        </div>
        <div className="a-text" style={{ marginBlockStart: "2rem" }}>
          <h2>Custom Component Showcase</h2>
          <div style={{ padding: "1rem" }}>
            {/* <div className="-emphasis-00-nested" style={{ padding: "1rem" }}> */}
            <div className="your-custom-component">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Excepturi, modi.
              </p>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At,
                laboriosam!
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
