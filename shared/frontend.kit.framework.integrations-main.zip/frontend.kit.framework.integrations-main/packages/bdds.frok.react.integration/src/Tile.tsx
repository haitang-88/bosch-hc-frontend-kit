import "@bosch/frontend.kit-npm/atoms/tile.css";

export default function TileSecondary() {
  return (
    <div className="a-tile -secondary">
      <div
        tabIndex={0}
        className="a-chip -icon"
        role="button"
        aria-labelledby="chip-label-id-Tile-secondary background"
      >
        <i className="a-icon a-chip__icon boschicon-bosch-ic-emoji-happy"></i>
        <span
          id="chip-label-id-Tile-secondary background"
          className="a-chip__label"
        >
          Label
        </span>
      </div>

      <div className="a-text" style={{ marginBlockStart: "1rem" }}>
        <h3
          className="-size-xl"
          style={{ marginBottom: "0.5rem", marginTop: 0 }}
        >
          Headline
          <i
            className="a-icon ui-ic-inline-right-bold"
            style={{
              marginLeft: "0.5rem",
              fontSize: 24,
              verticalAlign: "baseline",
            }}
          ></i>
        </h3>
        <p className="-size-m" style={{ margin: 0 }}>
          Subheadline
        </p>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "row",
          gap: "1rem",
          marginBlockStart: "1rem",
        }}
      >
        <button
          type="button"
          className="a-button a-button--brand-primary -fixed"
        >
          <span className="a-button__label">Label</span>
        </button>

        <button
          type="button"
          className="a-button a-button--brand-secondary -fixed"
        >
          <span className="a-button__label">Label</span>
        </button>
      </div>
    </div>
  );
}
