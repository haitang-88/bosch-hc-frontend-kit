import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'tile',
  templateUrl: './tile.html',
  styleUrl: './tile.scss',
})
export class Tile {}
