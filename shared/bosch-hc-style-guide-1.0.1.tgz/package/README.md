# bosch-hc-style-guide

Bosch Home Comfort style guide workspace to build and package:

- `bosch-hc-frontend-kit` CSS/JS artifacts
- `bosch-hc-style-guide` CSS/JS artifacts

All build outputs are generated into `dist/` at the repository root.

## Repository usage

### 1) Install dependencies

Run once from repository root:

```bash
npm install
```

### 2) Build outputs location

Generated files are written to `dist/`.

Typical artifacts:

- `dist/bosch-hc-fontawesome.css`
- `dist/bosch-hc-fontawesome.min.css`
- `dist/bosch-hc-frontend-kit.css`
- `dist/bosch-hc-frontend-kit.min.css`
- `dist/bosch-hc-frontend-kit.min.js`
- `dist/bosch-hc-style-guide.css`
- `dist/bosch-hc-style-guide.min.css`
- `dist/bosch-hc-style-guide.min.js`
- `dist/fonts/*`

## Standalone build commands

### Build only bosch-hc-frontend-kit CSS

Development CSS:

```bash
npm run ensure:dist
npm run build:frontend-kit-dev
```

Production/minified CSS:

```bash
npm run ensure:dist
npm run build:frontend-kit-prod
```

### Build only bosch-hc-frontend-kit JS

```bash
npm run build:frontend-kit-js
```

### Build only bosch-hc-style-guide CSS

Development CSS:

```bash
npm run ensure:dist
npm run build:style-guide-dev
```

Production/minified CSS:

```bash
npm run ensure:dist
npm run build:style-guide-prod
```

### Build only bosch-hc-style-guide JS

```bash
npm run build:style-guide-js
```

## Build both CSS + JS for everything

This runs dev + prod CSS builds for both bundles and copies JS/fonts:

```bash
npm run build
```

If you only want one mode for CSS plus JS:

```bash
npm run build:css-dev
```

or

```bash
npm run build:css-prod
```

## Build package as `.tgz`

### Option A: Create tgz in repository root

```bash
npm pack
```

Notes:

- `prepack` runs automatically, so `npm run build` is executed before tarball creation.
- Output file format is like: `bosch-hc-style-guide-<version>.tgz`.

### Option B: Create tgz directly in `dist/`

```bash
npm run pack:local
```

This executes:

```bash
npm pack --pack-destination ./dist
```

Result: `.tgz` is written to `dist/`.

## Angular font assets

After installing `bosch-hc-style-guide` in an Angular project, open `angular.json` and add the following entry to the application's `assets` array:

```json
{
	"glob": "**/*",
	"input": "node_modules/bosch-hc-style-guide/dist/fonts",
	"output": "/fonts"
}
```

Then update the application's `styles` and `scripts` arrays. Please note, only add css and js needed for you project, in the example below, I add all css and js into project. The css and js should be in order as below:

```json
{
	"styles": [
		"node_modules/bosch-hc-style-guide/dist/bosch-hc-frontend-kit.min.css",
		"node_modules/bosch-hc-style-guide/dist/bosch-hc-style-guide.min.css",
		"node_modules/bosch-hc-style-guide/dist/bosch-hc-fontawesome.min.css"
	],
	"scripts": [
		"node_modules/bosch-hc-style-guide/dist/bosch-hc-frontend-kit.min.js",
		"node_modules/bosch-hc-style-guide/dist/bosch-hc-style-guide.min.js"
	]
}
```

## Watch mode (optional)

For iterative SCSS development:

```bash
npm run watch
```
